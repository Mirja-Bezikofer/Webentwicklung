let loggedInUser ="testuser"
document.addEventListener("DOMContentLoaded", function () {
    let fileInput = document.getElementById("fileInput");
    let videoElement = document.getElementById("videoPreview");

    fileInput.addEventListener("change", function (event) {
        let file = event.target.files[0];

        if (file) {
            let videoURL = URL.createObjectURL(file);
            videoElement.src = videoURL;
            videoElement.style.display = "block"; // Video sichtbar machen
            videoElement.style.width = "100%";  // Setzt die Breite auf 100% der Containergröße
            videoElement.style.height = "auto"; // Höhe passt sich automatisch an
            videoElement.load();
            videoElement.play();
            videoElement.loop = true;
        }
    });
});

function videoUpload() {
    // SQL-Statement, dass neuen Post hochlädt
    const fileInput = document.getElementById('fileInput');
    const videoTitle = document.getElementById('videoTitle').value;
    const videoTag = document.getElementById('videotags').value;
    const videoDescription = document.getElementById('videoDescription').value;
    formData.append('videoFile', "Beispieltext");
    formData.append('loggendInUser', loggedInUser);
    formData.append('title', videoTitle);
    formData.append('tag', videoTags); 
    formData.append('description', videoDescription);
    fetch("videoUpload.php", {
        method: "POST",
        body: formData
    })
    .then(response => response.text())
    .then(data => alert(data))
    .catch(error => console.error("Fehler:", error));
    alert("Post hochgeladen!");
}