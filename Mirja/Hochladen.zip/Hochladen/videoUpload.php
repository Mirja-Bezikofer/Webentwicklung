<?php
//Eingabe der Parameter um Verbindung herzustellen
$servername = "127.0.0.1";
$username = "root"; 
$password = ""; 
$dbname = "uFood"; 

// Verbindung herstellen
$connection = new mysqli($servername, $username, $password, $dbname);

// Verbindung überprüfen
if ($connection->connect_error) {
    die("Verbindung fehlgeschlagen: " .$connection->connect_error);
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $videofile = $_POST['filename'];
    $videotitle = $_POST['videotitle'];
    $videotag = $_POST['tag'];
    $videoDescription = $_POST['description'];
    $loggendInUser = $_POST['loggedInuser'];

    $stmt = $connection->prepare("INSERT INTO posts (gerichtname, loggedInUser, videopfad, beschreibung, tags_tagname ) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param($gerichtname, $loggendInUser, $videopfad, $beschreibung, $videotag);

    if ($stmt->execute()) {
        echo "Neuer Datensatz erfolgreich eingefügt.";
    } else {
        echo "Fehler: " .$stmt->error;
    }

    $stmt->close();
}
?>