<?php
//Eingabe der Parameter um Verbindung herzustellen
$servername = "127.0.0.1";
$username = "root"; 
$password = ""; 
$dbname = "uFood"; 

// Verbindung herstellen
$connection = new mysqli($servername, $username, $password, $dbname);

// Verbindung überprüfen
if ($connection->connect_error) {
    die("Verbindung fehlgeschlagen: " .$connection->connect_error);
}
$loggedinUser = "marvinjsh";
$loggedInUserProfilePicture ="";

$tags = $connection->query("SELECT tagname FROM tags");
while($row = $tags->fetch_assoc()) {
    $tagarray[] = $row["tagname"];
}
$connection->close();
?>
<html lang="de">
<head>
    <link rel="stylesheet" href="Hochladen.css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.png" type="image/png">
    <script src="Hochladen.js"></script>
    <meta charset="UTF-8">
    <title>uFood | Hochladen</title>
</head>
<body>
    <div class="sidebarleft">
        <div class="menubar">
            <div class="menu">
                <a href="ForYou.php" style="font-weight: bold; font-size: x-large;"><img src="https://i.ibb.co/G3ft2KtS/u-Food-Logo.png" alt="Logo nicht gefunden" style="height: 26px; width: 28px;">uFood</a>
                <a href="ForYou.php">ForYou</a>
                <a href="Suchfunktion.html">Suche</a>
                <a href="C:\Users\marvi\Documents\Studium\uFood\Hochladen\Hochladen.html">Hochladen</a>
                <a href="Profile.php">Profil</a>
                <a href="Über_uns.php">Über uns</a>
                <button onclick='location.href="Profile.php"'><?php echo $loggedinUser ?></button>
            </div>
        </div>
    </div>

   <div class="content">
        <div class="videoside">
        </div>
        <div class="video-container">
            <input type="file" id="fileInput" accept="video/*" style="display: none;">
            <video id="videoPreview" controls></video>
        </div>
        <div class="videoside">
            <img src="upload_24dp_000000_FILL0_wght400_GRAD0_opsz24.png" 
            alt="png nicht gefunden" 
            style="height: 50px; width: 50px; cursor: pointer;" 
            class="videobuttons"
            onclick="document.getElementById('fileInput').click();">
            <img src="check_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24.png" 
            alt="png nicht gefunden" 
            style="height: 50px; width: 50px; cursor: pointer;" 
            class="videobuttons"
            onclick="videoUpload()">
        </div>
    </div>

    <div class="sidebarright">
        <div class="slidebuttons">
        </div>
        <div class="commentbar">
            <div class="comments">
                <div style="font-weight: bold; padding-left: 10px">Informationen</div>
                <div class="info-container">
                <label for="videoTitle">Videoname:</label>
                <input type="text" id="videoTitle" placeholder="Gib den Videonamen ein...">
                <label for="videoTags">Tags:</label>
                <select id="videoTags">
                    <option value="" disabled selected>Wähle ein Tag...</option>
                    <?php
                        // PHP-Code, um die Tags als Optionen in das Dropdown-Menü einzufügen
                        foreach ($tagarray as $singletag) {
                        echo "<option value='$singletag'>$singletag</option>";
                    }
                    ?>
                </select>
                <label for="videoDescription">Beschreibung:</label>
                <textarea id="videoDescription" placeholder="Beschreibe dein Video..."></textarea>
            </div>
        </div>
    </div>
</html>